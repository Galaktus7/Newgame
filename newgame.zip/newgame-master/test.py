import os

ratid = 'https://i.gifer.com/I3ZZ.gif' #xz
newid = 'https://i.pinimg.com/originals/c6/60/9c/c6609cda7e25cc9297b5d346f542200b.gif' #fight
terrorid = 'https://66.media.tumblr.com/f493d98acfddfc4aceb7059de14de460/tumblr_pfmi6cj8fQ1rj78ymo1_1280.gif' #lich
masterid = 'https://66.media.tumblr.com/6ebee24c225f390d3a33ca716c66c150/tumblr_inline_ohzzdr5WTM1uy5jr6_500.gif' #xujum
dragoid = 'https://vignette.wikia.nocookie.net/anime-characters-fight/images/c/cd/Медив07.gif/revision/latest?cb=20180401092135&path-prefix=ru' #begin
dogid = 'https://vignette.wikia.nocookie.net/anime-characters-fight/images/5/55/Медив03.gif/revision/latest?cb=20180401192844&path-prefix=ru' #himoya
rhinoid = 'AgADAgADbqoxG2TrgUkhECUTDgcfAkRsUw8ABGx3RFITYKWUotoFAAEC'
gameid = 'AgADAgADuasxGxGXeUlDpLyfuS6uCYpVUw8ABIBjKH6iBtWX5M8FAAEC'
supid = 'AgADAgADb6oxG2TrgUmcuN7VctFI-a5KUw8ABJibYbS7b2Ln59UFAAEC'
cusid = 'https://66.media.tumblr.com/383a515383458d7432cc186916ffd453/tumblr_pcu3r3C6eR1uhh267o2_540.gif' #strange
